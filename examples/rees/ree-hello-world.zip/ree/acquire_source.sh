#!/bin/sh
# repo2ree acquire-source — generated. Populates an upstream directory from the
# frozen snapshot, or by fetching the recorded origin and verifying its SWHID.
set -eu

ORIGIN_URL=''
SWHID='swh:1:dir:74737de6eb3cce57672e6a193df8a372f1d98928'
UPSTREAM_DIRNAME='upstream'
SNAPSHOT_FILENAME='snapshot.tar.gz'

REE_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
upstream="$REE_ROOT/$UPSTREAM_DIRNAME"
snapshot="$REE_ROOT/$SNAPSHOT_FILENAME"

say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
usage() { echo "usage: $0 [--refetch]" >&2; exit 2; }

REFETCH=0
while [ $# -gt 0 ]; do
  case "$1" in
    --refetch) REFETCH=1 ;;
    *) usage ;;
  esac
  shift
done

# Best-effort source-identity check. The fetch already happened; a local machine
# may lack the `swh` tool, so a missing tool — or a mismatch — only warns.
verify_swhid() {
  dir=$1
  [ -n "$SWHID" ] || { say "No recorded SWHID; source identity not verified."; return 0; }
  if command -v swh >/dev/null 2>&1; then
    actual=$(swh identify --no-filename "$dir" 2>/dev/null || true)
    if printf '%s' "$actual" | grep -qF "$SWHID"; then
      say "Source identity verified against SWHID."
    else
      say "WARNING: source SWHID mismatch (recorded $SWHID, got ${actual:-none}) — reproduction may differ."
    fi
  else
    say "WARNING: 'swh' not installed; fetched source but could not verify against $SWHID."
  fi
}

fetch_source() {
  die 'no origin recorded; cannot fetch'
}

# Idempotent: a populated upstream is left alone unless a re-fetch was asked for.
if [ "$REFETCH" -eq 0 ] && [ -d "$upstream" ] && [ -n "$(ls -A "$upstream" 2>/dev/null)" ]; then
  say "upstream already populated; nothing to do."
  exit 0
fi

rm -rf "$upstream"; mkdir -p "$upstream"

if [ "$REFETCH" -eq 1 ] && [ -n "$ORIGIN_URL" ]; then
  fetch_source "$upstream"
  verify_swhid "$upstream"
elif [ -f "$snapshot" ]; then
  say "Extracting frozen snapshot (identity sealed in)."
  tar -xzf "$snapshot" -C "$upstream"
elif [ -n "$ORIGIN_URL" ]; then
  fetch_source "$upstream"
  verify_swhid "$upstream"
else
  say "WARNING: no snapshot at $snapshot and no origin recorded — leaving upstream empty (overlay-only)."
fi
