#!/usr/bin/env sh
set -eu

# The run script materialized its stdout to this workspace file; read it back.
EXPECTED="Pandas Hello World"
grep -Fq "$EXPECTED" "result.txt"
