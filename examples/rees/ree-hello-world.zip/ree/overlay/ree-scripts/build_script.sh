#!/usr/bin/env sh
set -eu

IMAGE_NAME="pandas-hello"
TAG="latest"
PROJECT_DIR="python_hello_world"
RUNTIME_FILE="python_hello_world/runtime.tar"

docker build -t "$IMAGE_NAME:$TAG" "$PROJECT_DIR"
docker save "$IMAGE_NAME:$TAG" -o "$RUNTIME_FILE"
