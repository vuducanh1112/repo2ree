# Reproducing this REE

This is a sealed **repo2ree** Reproducible Execution Environment (REE). It is
self-contained: you can reproduce it on your own machine without installing
repo2ree. Everything needed is in this archive.

## Prerequisites

- A POSIX shell and `tar` (present on macOS/Linux; on Windows use WSL or Git
  Bash).
- Whatever experiment environment the author's scripts call into — commonly **Docker**. The
  activation test and every experiment run inside
  `ree-scripts/activate_experiment_environment.sh` (for example its `docker run …`), so
  read `./overlay/` if you want to see exactly what will run.
- Only if the source was **not** bundled: the fetch tool for its type (`git`,
  `curl`, `unzip`) and, optionally, the `swh` CLI to verify source identity
  against the recorded SWHID. Without `swh` the source is still fetched; it just
  cannot be cryptographically verified.

## Environment

The author's scripts ran in the OCI image `docker.io/library/docker:29-dind@sha256:66d292e5c26bd33a6f6f61cacb880de2186339a524ecba1ce098dbbaceed6515`.

## Layout

```
run.sh                 one-click entrypoint (this is what you run)
REPRODUCING.md         this file
./ree.json           the sealed manifest (name, experiments, outputs, …)
./snapshot.tar.gz    frozen upstream source (omitted for a sourceless seal)
./overlay/           author scripts (build / activation / experiments)
./artifacts/         sealed build outputs (experiment environment image, SBOM, …)
./workspace/         created by run.sh: upstream + overlay merged
```

## Run it

From the folder where you extracted this archive, the one-click path runs the
whole REE end-to-end against a single workspace — acquire, materialize, experiment environment,
activation, then every experiment in order:

```shell
sh run.sh all        # reproduce everything end-to-end (one click)
```

Or drive it one phase at a time:

```shell
sh run.sh                          # materialize a clean workspace and list commands
sh run.sh acquire-source           # extract/fetch the source (verify SWHID if able)
sh run.sh materialize-workspace    # assemble a clean workspace = source + overlay
sh run.sh build-experiment-environment            # build the experiment environment from the author's build script
sh run.sh test-activation          # enter the experiment environment and hand over
sh run.sh experiment <name>        # run a named experiment and verify its result
sh run.sh verify <name>            # verify only, without re-running
sh run.sh list                     # list commands again
```

## Verification

An experiment may ship a *verify script* beside its run script (listed by
`sh run.sh list`). After the run script finishes, `run.sh` executes the
verify script from the workspace root, outside the experiment environment — a plain
`sh` script with nothing injected into its environment — and reports
`VERIFIED: pass` or `VERIFIED: fail`. Its exit code is the verdict
(0 = pass), so the claimed result is checked on your machine, not just
re-run. The verify script reads whatever it checks straight from the
workspace (a run script that wants its stdout checked materializes it to a
workspace file). Verify scripts are plain `sh` in `./overlay/`
— read them to see exactly what is being claimed.

To re-check a claim without re-running the experiment, use `sh run.sh verify
<name>`: it runs only the verify
script against the outputs the previous run left in the workspace. It fails
if those outputs are absent — because the experiment hasn't run yet, or the
workspace was reset since.

`materialize-workspace` assembles `./workspace/` from the acquired source with
the author scripts overlaid on top, so each script runs from the workspace root
exactly as it did when the REE was authored. It resets the workspace, so a
re-run starts from a clean slate; the sealed experiment environment is re-restored from
`./artifacts/` (a copy, not a rebuild). When no experiment environment was sealed in,
`build-experiment-environment` produces it.
