#!/bin/sh
# repo2ree reproducer — generated at seal time. Runs without a repo2ree install.
#
# Layout (siblings of this script):
#   ree/ree.json          the sealed manifest
#   ree/snapshot.tar.gz    frozen upstream source (omitted for a sourceless seal)
#   ree/overlay/           author scripts (build/activation/experiments)
#   ree/artifacts/         sealed build outputs (experiment environment, sbom, ...)
#   ree/upstream/          acquired source layer (created by acquire-source)
#   ree/workspace/         clean view = upstream + overlay (created by materialize)
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REE="$HERE"
WS="$REE/workspace"

# --- generated registry -----------------------------------------------------
BUILD_EXPERIMENT_ENVIRONMENT_SCRIPT='ree-scripts/build_experiment_environment.sh'
ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT='ree-scripts/activate_experiment_environment.sh'
EXPERIMENT_ENVIRONMENT_WS_PATH='source/runtime.tar'
EXPERIMENT_ENVIRONMENT_ARTIFACT='runtime.tar'

experiments() {
  cat <<'__R2R_EXPERIMENTS__'
python-hello	ree-scripts/experiments/python-hello.sh	ree-scripts/experiments/python-hello.verify.sh
__R2R_EXPERIMENTS__
}
# ----------------------------------------------------------------------------

say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }

# Populate the upstream source layer: extract the bundled snapshot, else fetch
# from the recorded origin and verify the SWHID. Delegated to the bundled
# acquire script — the very same one the workbench ran at authoring time — so
# the two cannot drift. Pass REPRODUCE_REFETCH=1 to force a fresh origin pull.
do_acquire() {
  set --
  [ "${REPRODUCE_REFETCH:-0}" = "1" ] && set -- "$@" --refetch
  sh "$REE/acquire_source.sh" "$@"
}

# Re-restore the sealed experiment environment to its workspace path (a cheap copy). Returns
# non-zero when no experiment environment was sealed in, so callers can fall back to building.
restore_experiment_environment() {
  [ -n "$EXPERIMENT_ENVIRONMENT_WS_PATH" ] && [ -n "$EXPERIMENT_ENVIRONMENT_ARTIFACT" ] \
    && [ -f "$REE/artifacts/$EXPERIMENT_ENVIRONMENT_ARTIFACT" ] || return 1
  dest="$WS/$EXPERIMENT_ENVIRONMENT_WS_PATH"
  mkdir -p "$(dirname -- "$dest")"
  cp "$REE/artifacts/$EXPERIMENT_ENVIRONMENT_ARTIFACT" "$dest"
}

# Assemble a clean workspace = upstream + overlay (overlay wins), then re-restore
# the sealed experiment environment. The clear-and-merge is delegated to the bundled materialize
# script — the very same one the workbench ran at authoring time — so the two
# cannot drift. Acquire and the experiment environment restore stay here as orchestration.
do_materialize() {
  do_acquire
  sh "$REE/materialize_workspace.sh"
  restore_experiment_environment || true
}

# Set up the workspace only if it is not already materialized (non-destructive),
# so running one verb after another does not silently reset state.
ensure_workspace() {
  if [ ! -d "$WS" ] || [ -z "$(ls -A "$WS" 2>/dev/null)" ]; then
    do_materialize
  fi
}

# Reuse the sealed experiment environment when present; otherwise build it once.
ensure_experiment_environment() {
  if restore_experiment_environment; then
    say "Reusing sealed experiment environment -> $EXPERIMENT_ENVIRONMENT_WS_PATH (build skipped)"
  else
    do_build
  fi
}

run_in_workspace() {
  script=$1
  [ -f "$WS/$script" ] || die "script not found in workspace: $script"
  say "\$ sh $script"
  ( cd "$WS" && sh "$script" )
}

# Run just a verify script from the workspace root (no run script). The
# verify script is a plain author script with nothing injected into its
# environment; its exit code is the verdict (0 = pass). It reads whatever it
# checks straight from the workspace — so this re-checks a claim against the
# outputs a previous run left there, without paying to re-run.
run_verify_only() {
  verify=$1
  [ -f "$WS/$verify" ] || die "verify script not found in workspace: $verify"
  say "\$ sh $verify"
  if ( cd "$WS" && sh "$verify" ); then
    say "VERIFIED: pass"
  else
    vrc=$?
    say "VERIFIED: fail (verify exit $vrc)"
    return 1
  fi
}

require_activation() {
  [ -f "$WS/$ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT" ] \
    || die "script not found in workspace: $ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT"
}

run_activated() {
  script=$1
  [ -f "$WS/$script" ] || die "script not found in workspace: $script"
  require_activation
  say "\$ sh $ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT sh $script"
  ( cd "$WS" && sh "$ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT" sh "$script" )
}

# The activation alone, around a command that does nothing: it enters the experiment
# environment and hands over.
run_activation() {
  require_activation
  say "\$ sh $ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT true"
  ( cd "$WS" && sh "$ACTIVATE_EXPERIMENT_ENVIRONMENT_SCRIPT" true )
}

# Run a run script inside the activated experiment environment, then its verify
# script (when declared) outside it.
run_verified() {
  script=$1; verify=${2:-}
  run_activated "$script"
  [ -z "$verify" ] && return 0
  run_verify_only "$verify"
}

do_build() {
  ensure_workspace
  say "== build-experiment-environment =="
  run_in_workspace "$BUILD_EXPERIMENT_ENVIRONMENT_SCRIPT"
}

do_activate() {
  ensure_workspace; ensure_experiment_environment
  say "== test-activation =="
  run_activation
}

do_experiment() {
  name=${1:-}
  [ -n "$name" ] || die "usage: $0 experiment <name>"
  line=$(experiments | while IFS='	' read -r n s v; do
    if [ "$n" = "$name" ]; then printf '%s	%s' "$s" "$v"; break; fi
  done)
  [ -n "$line" ] || die "no experiment named: $name (try '$0 list')"
  script=$(printf '%s' "$line" | cut -f1)
  verify=$(printf '%s' "$line" | cut -f2)
  ensure_workspace; ensure_experiment_environment
  say "== experiment: $name =="
  run_verified "$script" "$verify"
}

# Verify only: re-check an experiment's claim against the outputs a previous run
# left in the workspace, without re-running. Needs the workspace populated but not
# the experiment environment (the verify script only reads workspace files). Fails if the
# experiment declares no verify script, or if the outputs it expects are absent
# (never produced, or the workspace was reset since the run).
do_verify() {
  name=${1:-}
  [ -n "$name" ] || die "usage: $0 verify <name>"
  ensure_workspace
  match=$(experiments | while IFS='	' read -r n s v; do
    if [ "$n" = "$name" ]; then printf 'Y	%s' "$v"; break; fi
  done)
  [ -n "$match" ] || die "no experiment named: $name (try '$0 list')"
  verify=$(printf '%s' "$match" | cut -f2)
  [ -n "$verify" ] || die "experiment '$name' declares no verify script — nothing to verify"
  say "== verify: $name =="
  run_verify_only "$verify"
}

# One-click: acquire -> materialize -> experiment environment -> activation -> every experiment.
# Runs against a single materialized workspace (experiments are not isolated from
# each other). Aborts on the first failure (set -e), including inside the loop.
do_all() {
  do_materialize
  ensure_experiment_environment
  say "== test-activation =="
  run_activation
  experiments | while IFS='	' read -r n s v; do
    [ -n "$n" ] || continue
    say "== experiment: $n =="
    run_verified "$s" "$v"
  done
  say ""
  say "All steps completed."
}

do_list() {
  say "Reproduction commands:"
  say "  acquire-source          Acquire the source, verifying it against the recorded SWHID"
  say "  materialize-workspace   Assemble a clean workspace from the source and the REE overlay"
  say "  build-experiment-environmentBuild the experiment environment from the REE build script"
  say "  test-activation         Run the activation alone: it enters the experiment environment and hands over"
  say "  experiment              Run a named experiment and verify its result"
  if experiments | grep -q .; then
    say ""
    say "Experiments:"
    experiments | while IFS='	' read -r n s v; do
      [ -z "$n" ] && continue
      if [ -n "$v" ]; then
        say "  $n  ->  $s (verified by $v)"
      else
        say "  $n  ->  $s"
      fi
    done
  fi
  say ""
  say "Run everything end-to-end:      sh $0 all"
  say "Or one phase at a time, e.g.:    sh $0 experiment <name>"
  say "Re-check a claim without re-running: sh $0 verify <name>"
}

case "${1:-}" in
  "")            do_materialize; say ""; do_list ;;
  all|reproduce) do_all ;;
  verify)        shift; do_verify "${1:-}" ;;
  acquire-source) do_acquire ;;
  materialize-workspace) do_materialize ;;
  build-experiment-environment) do_build ;;
  test-activation) do_activate ;;
  experiment) shift; do_experiment "${1:-}" ;;
  list)          ensure_workspace; do_list ;;
  -h|--help|help) do_list ;;
  *)             die "unknown command: $1 (try '$0 list')" ;;
esac
