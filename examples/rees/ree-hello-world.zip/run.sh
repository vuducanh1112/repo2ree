#!/bin/sh
# repo2ree reproducer — generated at seal time. Runs without a repo2ree install.
#
# Layout (siblings of this script):
#   ree/ree.json          the sealed manifest
#   ree/snapshot.tar.gz    frozen upstream source (omitted for a sourceless seal)
#   ree/overlay/           author scripts (build/activation/experiments)
#   ree/artifacts/         sealed build outputs (runtime, sbom, ...)
#   ree/upstream/          acquired source layer (created by acquire-source)
#   ree/workspace/         clean view = upstream + overlay (created by materialize)
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REE="$HERE/ree"
WS="$REE/workspace"

# --- generated registry -----------------------------------------------------
BUILD_SCRIPT='ree-scripts/build_script.sh'
ACTIVATION_SCRIPT='ree-scripts/activation.sh'
ACTIVATION_VERIFY_SCRIPT=''
RUNTIME_WS_PATH='python_hello_world/runtime.tar'
RUNTIME_ARTIFACT='runtime.tar'

experiments() {
  cat <<'__R2R_EXPERIMENTS__'
python-hello	ree-scripts/experiments/python-hello.sh	ree-scripts/experiments/python-hello.verify.sh
__R2R_EXPERIMENTS__
}
# ----------------------------------------------------------------------------

say() { printf '%s\n' "$*"; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }

# Populate the upstream source layer: extract the bundled snapshot, else fetch
# from the recorded origin and verify the SWHID. Delegated to the bundled
# acquire script — the very same one the workbench ran at authoring time — so
# the two cannot drift. Pass REPRODUCE_REFETCH=1 to force a fresh origin pull.
do_acquire() {
  set --
  [ "${REPRODUCE_REFETCH:-0}" = "1" ] && set -- "$@" --refetch
  sh "$REE/acquire_source.sh" "$@"
}

# Re-restore the sealed runtime to its workspace path (a cheap copy). Returns
# non-zero when no runtime was sealed in, so callers can fall back to building.
restore_runtime() {
  [ -n "$RUNTIME_WS_PATH" ] && [ -n "$RUNTIME_ARTIFACT" ] \
    && [ -f "$REE/artifacts/$RUNTIME_ARTIFACT" ] || return 1
  dest="$WS/$RUNTIME_WS_PATH"
  mkdir -p "$(dirname -- "$dest")"
  cp "$REE/artifacts/$RUNTIME_ARTIFACT" "$dest"
}

# Assemble a clean workspace = upstream + overlay (overlay wins), then re-restore
# the sealed runtime. The clear-and-merge is delegated to the bundled materialize
# script — the very same one the workbench ran at authoring time — so the two
# cannot drift. Acquire and the runtime restore stay here as orchestration.
do_materialize() {
  do_acquire
  sh "$REE/materialize_workspace.sh"
  restore_runtime || true
}

# Set up the workspace only if it is not already materialized (non-destructive),
# so running one verb after another does not silently reset state.
ensure_workspace() {
  if [ ! -d "$WS" ] || [ -z "$(ls -A "$WS" 2>/dev/null)" ]; then
    do_materialize
  fi
}

# Reuse the sealed runtime when present; otherwise build it once.
ensure_runtime() {
  if restore_runtime; then
    say "Reusing sealed runtime -> $RUNTIME_WS_PATH (build skipped)"
  else
    do_build
  fi
}

run_in_workspace() {
  script=$1
  [ -f "$WS/$script" ] || die "script not found in workspace: $script"
  say "\$ sh $script"
  ( cd "$WS" && sh "$script" )
}

# Run just a verify script from the workspace root (no run script). The
# verify script is a plain author script with nothing injected into its
# environment; its exit code is the verdict (0 = pass). It reads whatever it
# checks straight from the workspace — so this re-checks a claim against the
# outputs a previous run left there, without paying to re-run.
run_verify_only() {
  verify=$1
  [ -f "$WS/$verify" ] || die "verify script not found in workspace: $verify"
  say "\$ sh $verify"
  if ( cd "$WS" && sh "$verify" ); then
    say "VERIFIED: pass"
  else
    vrc=$?
    say "VERIFIED: fail (verify exit $vrc)"
    return 1
  fi
}

# Run a run script, then its verify script (when declared). An author who
# wants to check stdout has the run script materialize it to a workspace
# file (e.g. `| tee results/run.log`) that the verify script reads back.
run_verified() {
  script=$1; verify=${2:-}
  run_in_workspace "$script"
  [ -z "$verify" ] && return 0
  run_verify_only "$verify"
}

do_build() { ensure_workspace; say "== build-runtime =="; run_in_workspace "$BUILD_SCRIPT"; }

do_activate() {
  ensure_workspace; ensure_runtime
  say "== test-activation =="
  run_verified "$ACTIVATION_SCRIPT" "$ACTIVATION_VERIFY_SCRIPT"
}

do_experiment() {
  name=${1:-}
  [ -n "$name" ] || die "usage: $0 experiment <name>"
  line=$(experiments | while IFS='	' read -r n s v; do
    if [ "$n" = "$name" ]; then printf '%s	%s' "$s" "$v"; break; fi
  done)
  [ -n "$line" ] || die "no experiment named: $name (try '$0 list')"
  script=$(printf '%s' "$line" | cut -f1)
  verify=$(printf '%s' "$line" | cut -f2)
  ensure_workspace; ensure_runtime
  say "== experiment: $name =="
  run_verified "$script" "$verify"
}

# Verify only: re-check a claim against the outputs a previous run left in
# the workspace, without re-running. With a name, verifies that experiment;
# with no name, verifies activation. Needs the workspace populated but not
# the runtime (the verify script only reads workspace files). Fails if the
# subject declares no verify script, or if the outputs it expects are absent
# (never produced, or the workspace was reset since the run).
do_verify() {
  name=${1:-}
  ensure_workspace
  if [ -z "$name" ]; then
    [ -n "$ACTIVATION_VERIFY_SCRIPT" ] || die "activation declares no verify script — nothing to verify"
    say "== verify: activation =="
    run_verify_only "$ACTIVATION_VERIFY_SCRIPT"
    return
  fi
  match=$(experiments | while IFS='	' read -r n s v; do
    if [ "$n" = "$name" ]; then printf 'Y	%s' "$v"; break; fi
  done)
  [ -n "$match" ] || die "no experiment named: $name (try '$0 list')"
  verify=$(printf '%s' "$match" | cut -f2)
  [ -n "$verify" ] || die "experiment '$name' declares no verify script — nothing to verify"
  say "== verify: $name =="
  run_verify_only "$verify"
}

# One-click: acquire -> materialize -> runtime -> activation -> every experiment.
# Runs against a single materialized workspace (experiments are not isolated from
# each other). Aborts on the first failure (set -e), including inside the loop.
do_all() {
  do_materialize
  ensure_runtime
  say "== test-activation =="
  run_verified "$ACTIVATION_SCRIPT" "$ACTIVATION_VERIFY_SCRIPT"
  experiments | while IFS='	' read -r n s v; do
    [ -n "$n" ] || continue
    say "== experiment: $n =="
    run_verified "$s" "$v"
  done
  say ""
  say "All steps completed."
}

do_list() {
  say "Reproduction commands:"
  say "  acquire-source          Acquire the source, verifying it against the recorded SWHID"
  say "  materialize-workspace   Assemble a clean workspace from the source and the REE overlay"
  say "  build-runtime           Build the runtime from the REE build script"
  say "  test-activation         Run activation to prove the runtime is inhabitable"
  say "  experiment              Run a named experiment and verify its result"
  if experiments | grep -q .; then
    say ""
    say "Experiments:"
    experiments | while IFS='	' read -r n s v; do
      [ -z "$n" ] && continue
      if [ -n "$v" ]; then
        say "  $n  ->  $s (verified by $v)"
      else
        say "  $n  ->  $s"
      fi
    done
  fi
  say ""
  say "Run everything end-to-end:      sh $0 all"
  say "Or one phase at a time, e.g.:    sh $0 experiment <name>"
  say "Re-check a claim without re-running: sh $0 verify <name>"
}

case "${1:-}" in
  "")            do_materialize; say ""; do_list ;;
  all|reproduce) do_all ;;
  verify)        shift; do_verify "${1:-}" ;;
  acquire-source) do_acquire ;;
  materialize-workspace) do_materialize ;;
  build-runtime) do_build ;;
  test-activation) do_activate ;;
  experiment) shift; do_experiment "${1:-}" ;;
  list)          ensure_workspace; do_list ;;
  -h|--help|help) do_list ;;
  *)             die "unknown command: $1 (try '$0 list')" ;;
esac
